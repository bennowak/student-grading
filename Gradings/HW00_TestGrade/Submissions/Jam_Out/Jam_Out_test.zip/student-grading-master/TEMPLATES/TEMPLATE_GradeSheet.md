# Assignment : <assignment>

## Student Name : <name>

### Due Date : <due>

### Submitted Date : <submit>

### Graded By: <graded_by>

### Grade : <grade>

### Grading Revisions

1. Grade:<newGrade> Date: <date> Reason: <reason>

## Rubric (Usually Given in TA Assignement Repo)

#### Basic Requirements

- [ ] The assignment utilizes Excel to analyze Kickstarter data
- [ ] The solution should run without error, producing summary analysis of the data
- [ ] ~~The source code should also be deployed to ***\*Github\**** or ***\*Gitlab\****~~

#### Part 1

- [ ] Grading Consideration

- [ ] Grading Consideration

- ##### Bonus

  - [ ] Grading Consideration

#### Part 2

- [ ] Grading Consideration
- [ ] Grading Consideration

## Notes

- Note 1
- Note 2
